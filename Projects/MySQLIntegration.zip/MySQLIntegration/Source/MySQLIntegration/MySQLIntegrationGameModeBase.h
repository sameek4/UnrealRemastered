// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "MySQLIntegrationGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class MYSQLINTEGRATION_API AMySQLIntegrationGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
	
	
	
};
